import numpy
import math
import ipcv
import cv2

#from scipy.ndimage.filters import generic_gradient_magniture, sobel



def energy(im):
    blur = cv2.GaussianBlur(im, (3,3), 0, 0)
    gray = cv2.cvtColor(blur, cv2.COLOR_BGR2GRAY)
    dx = cv2.Sobel(gray, cv2.CV_8U, 1, 0, ksize=3, scale=1, delta=0, borderType=cv2.BORDER_DEFAULT)
    dy = cv2.Sobel(gray, cv2.CV_8U, 0, 1, ksize=3, scale=1, delta=0, borderType=cv2.BORDER_DEFAULT)

    energy = cv2.add(numpy.absolute(dx), numpy.absolute(dy))
    return energy

def cumulative_energies_vertical(energy):
    height, width = energy.shape[:2]
    energies = numpy.zeros((height, width))

    for i in range(1, height):
        for j in range(width):
            left = energies[i - 1, j - 1] if j - 1 >= 0 else 1e6
            middle = energies[i - 1, j]
            right = energies[i - 1, j + 1] if j + 1 < width else 1e6

            energies[i, j] = energy[i, j] + min(left, middle, right)

    return energies

def cumulative_energies_horizontal(energy):
    height, width = energy.shape[:2]
    energies = numpy.zeros((height, width))

    for j in range(1, width):
        for i in range(height):
            top = energies[i - 1, j - 1] if i - 1 >= 0 else 1e6
            middle = energies[i, j - 1]
            bottom = energies[i + 1, j - 1] if i + 1 < height else 1e6

            energies[i, j] = energy[i, j] + min(top, middle, bottom)

    return energies

def horizontal_seam(energies):
    height, width = energies.shape[:2]
    previous = 0
    seam = []

    for i in range(width - 1, -1, -1):
        col = energies[:, i]

        if i == width - 1:
            previous = numpy.argmin(col)

        else:
            top = col[previous - 1] if previous - 1 >= 0 else 1e6
            middle = col[previous]
            bottom = col[previous + 1] if previous + 1 < height else 1e6

            previous = previous + numpy.argmin([top, middle, bottom]) - 1

        seam.append([i, previous])

    return seam

def vertical_seam(energies):
    height, width = energies.shape[:2]
    previous = 0
    seam = []

    for i in range(height - 1, -1, -1):
        row = energies[i, :]

        if i == height - 1:
            previous = numpy.argmin(row)
            seam.append([previous, i])
        else:
            left = row[previous - 1] if previous - 1 >= 0 else 1e6
            middle = row[previous]
            right = row[previous + 1] if previous + 1 < width else 1e6

            previous = previous + numpy.argmin([left, middle, right]) - 1
            seam.append([previous, i])

    return seam


def remove_seam(im, seam):

    attempt = 0
    i = 0
    height, width = im.shape[:2]

    seamFitness = numpy.zeros((height, width))
    for attempt in range(attempt, im.size):
        bestRow = 0
        for i in range(i,height-im.size):
            if ([seamFitness[width-1]][bestRow] > seamFitness[width-1][i]):
                bestRow = i
    x = width-1
    if (x > 0):
        theMin = seamFitness[x-1][bestRow]
    if (bestRow > 0 and seamFitness[x-1][bestRow-1] <= theMin):
        bestRow = bestRow - 1
    elif (bestRow < height - 1 and seamFitness[x-1][bestRow+1] <= theMin):
        bestRow = bestRow + 1
    return im


def remove_horizontal_seam(im, seam):
    height, width, bands = im.shape

    removed = numpy.zeros((height-1, width, bands), numpy.uint8)

    for x, y in reversed(seam):
        removed[0:y,x] = im[0:y,x]
        removed[y:height-1,x] = im[y+1:height,x]

    return removed

def remove_vertical_seam(im, seam):

    height, width, bands = im.shape
    removed = numpy.zeros((height, width-1, bands), numpy.uint8)

    for x, y in reversed(seam):
        removed[y, 0:x] = im[y, 0:x]
        removed[y, x:width-1] = im[y, x+1:width]

    return removed

def seam_carving(im):


    result = im

    height = 200
    width = 200
    im_height, im_width = im.shape[:2]

    dy = im_height - height if im_height - height > 0 else 0
    dx = im_width - width if im_width - width > 0 else 0

    for i in range(dy):
        energies = cumulative_energies_horizontal(energy(result))

        seam = horizontal_seam(energies)
        cv2.polylines(im, numpy.int32([numpy.asarray(seam)]), False, (0,0,255))
        cv2.namedWindow('Original', cv2.WINDOW_AUTOSIZE)
        cv2.imshow('Original', im)
        result = remove_horizontal_seam(result, seam)

    for i in range(dx):
        energies = cumulative_energies_vertical(energy(result))
        seam = vertical_seam(energies)
        cv2.polylines(result, numpy.int32([numpy.asarray(seam)]), False, (0,0,255))
        cv2.namedWindow('Original', cv2.WINDOW_AUTOSIZE)
        cv2.imshow('Original', im)

        result = remove_vertical_seam(result, seam)

    cv2.namedWindow('seam', cv2.WINDOW_AUTOSIZE)
    cv2.imshow('seam', result)


if __name__ == "__main__":


    import numpy
    import cv2
    import os.path
    import ipcv
    import time

    home = os.path.expanduser('~')
    filename = home + os.path.sep + 'src/python/examples/data/balloon.jpg'

    im = cv2.imread(filename)

#    cv2.namedWindow("Original", cv2.WINDOW_AUTOSIZE)
#    cv2.imshow("Original", im)



    startTime = time.time()
    ipcv.seam_carving(im)

    print('Elapsed time = {0} [min]'.format(time.time() - startTime))
#    cv2.namedWindow('seam', cv2.WINDOW_AUTOSIZE)
#    cv2.imshow('seam', result)

    action = ipcv.flush()
